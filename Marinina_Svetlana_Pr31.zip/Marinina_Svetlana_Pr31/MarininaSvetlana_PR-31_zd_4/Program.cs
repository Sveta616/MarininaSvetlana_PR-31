﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Linq;

namespace MarininaSvetlana_PR_31_zd_4
{
    class Program
    {
        static void Main(string[] args)
        {

            var lengths = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            int messagelenght= lengths[0];
            int newspapelenght = lengths[1];

            string message = Console.ReadLine();
            string newspaper = Console.ReadLine();

            var messageWords = message.Split(' ');
            var newspaperWords = newspaper.Split(' ');

            var wordCount = new Dictionary<string, int>();
            foreach (var word in newspaperWords)
            {
                if (wordCount.ContainsKey(word))
                {
                    wordCount[word]++;
                }
                else
                {
                    wordCount[word] = 1;
                }
            }

            foreach (var word in messageWords)
            {
                if (!wordCount.ContainsKey(word) || wordCount[word] == 0)
                {
                    Console.WriteLine(word);
                    return;
                }
                wordCount[word]--;
            }

            Console.WriteLine("GOOD NOTE");


            Console.ReadKey();
        }
    }
}
