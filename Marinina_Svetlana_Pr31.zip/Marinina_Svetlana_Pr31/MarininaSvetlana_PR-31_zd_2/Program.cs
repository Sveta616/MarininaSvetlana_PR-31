﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MarininaSvetlana_PR_31_zd_2
{
    class Program
    {
        static bool PalindromProverka(string word)
        {
            string upper = word.ToUpper();
            for (int i = 0; i < upper.Length / 2; i++)
            {
                if (upper[i] != upper[upper.Length - i - 1])
                {
                    return false;
                }
            }
            return true;
        }
            static void Main(string[] args)
        {
                StreamReader read = new StreamReader("input.txt");
                StreamWriter write = new StreamWriter("output.txt");
                int s = int.Parse(read.ReadLine());
                string[] words = new string[s];
                for (int i = 0; i < s; i++)
                {
                    words[i] = read.ReadLine();
                }
                foreach (string word in words)
                {
                    if (PalindromProverka(word))
                    {
                        write.WriteLine("YES");
                    }
                    else
                    {
                        write.WriteLine("NO");
                    }
                }
              
                read.Close();
                write.Close();  
                Console.ReadKey();
        }
    }
}
