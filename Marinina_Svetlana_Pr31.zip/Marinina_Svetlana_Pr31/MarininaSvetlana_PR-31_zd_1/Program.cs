﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MarininaSvetlana_PR_31_zd_1
{
    class Program
    {
        static void Main(string[] args)
        {
           int a, b;
                StreamReader sr = new StreamReader("input.txt");
                string[] s = sr.ReadToEnd().Split(' ');
                a = Convert.ToInt32(s[0]);
                b = Convert.ToInt32(s[1]);
                sr.Close();
                StreamWriter sw = new StreamWriter("output.txt");
                sw.WriteLine(b / a);
                sw.Close();
              Console.ReadKey();
        }
    }
}
